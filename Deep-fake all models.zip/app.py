from flask import Flask, request, jsonify, send_file, render_template
import os
from tensorflow.keras.models import load_model
import cv2
import dlib
import numpy as np
from tensorflow.keras.preprocessing.image import img_to_array
import matplotlib.pyplot as plt
import json

app = Flask(__name__)

# Paths to models and metrics
models = {
    'inception': 'models/inception_resnet_v2_model.keras',
    'efficientnet': 'models/efficient_net_model_b4.keras',
    'vgg16': 'models/vgg16_model.keras'
}

def predict_frame(model, frame):
    detector = dlib.get_frontal_face_detector()
    face_rects, scores, idx = detector.run(frame, 0)
    predictions = []

    for i, d in enumerate(face_rects):
        x1 = d.left()
        y1 = d.top()
        x2 = d.right()
        y2 = d.bottom()
        crop_img = frame[y1:y2, x1:x2]
        data = img_to_array(cv2.resize(crop_img, (128, 128))).flatten() / 255.0
        data = data.reshape(-1, 128, 128, 3)

        # Get predicted probabilities
        predictions_prob = model.predict(data)
        # Convert probabilities to class predictions
        prediction = np.argmax(predictions_prob, axis=1)
        predictions.append(prediction[0])

    return predictions

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/process_video', methods=['POST'])
def process_video():
    model_name = request.form['model']
    video_file = request.files['video']
    
    if model_name not in models:
        return jsonify({'error': 'Invalid model name'})
    
    model_path = models[model_name]
    model = load_model(model_path)
    
    video_path = os.path.join('/tmp', video_file.filename)
    video_file.save(video_path)
    
    cap = cv2.VideoCapture(video_path)
    frameRate = cap.get(5)  # frame rate
    all_predictions = []
    frames = []
    
    while cap.isOpened():
        frameId = cap.get(1)  # current frame number
        ret, frame = cap.read()
        if not ret:
            break
        if frameId % ((int(frameRate) + 1) * 1) == 0:
            frame_predictions = predict_frame(model, frame)
            all_predictions.extend(frame_predictions)
            for prediction in frame_predictions:
                print(f"Prediction for frame {frameId}: {prediction}")
                # Save frame with prediction
                frame_filename = f"/tmp/frame_{frameId}.jpg"
                cv2.imwrite(frame_filename, frame)
                frames.append(frame_filename)

    cap.release()
    
    # Final verdict
    if len(all_predictions) > 0:
        verdict = 1 if np.mean(all_predictions) > 0.5 else 0
    else:
        verdict = 0  # Default to not a deepfake if no faces are detected
    
    return jsonify({
        'verdict': 'Deepfake (1)' if verdict == 1 else 'Not a Deepfake (0)',
        'frames': frames,
        'predictions': all_predictions
    })

@app.route('/metrics', methods=['GET'])
def metrics():
    # Assume we have metrics JSON files
    inception_metrics = 'models/inception_metrics.json'
    efficientnet_metrics = 'models/efficientnet_metrics.json'
    vgg16_metrics = 'models/vgg16_metrics.json'

    # Load the metrics for plotting
    with open(inception_metrics, 'r') as f:
        inception_history = json.load(f)
    with open(efficientnet_metrics, 'r') as f:
        efficientnet_history = json.load(f)
    with open(vgg16_metrics, 'r') as f:
        vgg16_history = json.load(f)

    # Plot metrics
    plt.figure(figsize=(20, 10))

    # Plot accuracy
    plt.subplot(2, 1, 1)
    plt.plot(inception_history['accuracy'], label='InceptionResNetV2 Accuracy')
    plt.plot(efficientnet_history['accuracy'], label='EfficientNetB4 Accuracy')
    plt.plot(vgg16_history['accuracy'], label='VGG16 Accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.legend()

    # Plot loss
    plt.subplot(2, 1, 2)
    plt.plot(inception_history['loss'], label='InceptionResNetV2 Loss')
    plt.plot(efficientnet_history['loss'], label='EfficientNetB4 Loss')
    plt.plot(vgg16_history['loss'], label='VGG16 Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()

    # Save the plot to a file
    plot_filename = '/tmp/metrics_plot.png'
    plt.savefig(plot_filename)
    
    return send_file(plot_filename, mimetype='image/png')

if __name__ == '__main__':
    app.run(debug=True)
